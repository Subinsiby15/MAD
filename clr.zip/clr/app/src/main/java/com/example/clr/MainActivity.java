package com.example.clr;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Declare the FrameLayout and ListView
    private FrameLayout colorFrame;
    private ListView colorListView;

    // List of color names
    private String[] colors = {"Red", "Green", "Blue", "Yellow", "Orange", "Purple", "Pink", "Black", "White", "Gray"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the FrameLayout and ListView
        colorFrame = findViewById(R.id.colorFrame);
        colorListView = findViewById(R.id.colorListView);

        // Create an ArrayAdapter to display the color names in the ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, colors);
        colorListView.setAdapter(adapter);

        // Set an item click listener for the ListView
        colorListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected color name
                String selectedColor = colors[position].toLowerCase();

                // Change the background color of the FrameLayout based on the selected color
                switch (selectedColor) {
                    case "red":
                        colorFrame.setBackgroundColor(Color.RED);
                        break;
                    case "green":
                        colorFrame.setBackgroundColor(Color.GREEN);
                        break;
                    case "blue":
                        colorFrame.setBackgroundColor(Color.BLUE);
                        break;
                    case "yellow":
                        colorFrame.setBackgroundColor(Color.YELLOW);
                        break;
                    case "orange":
                        colorFrame.setBackgroundColor(Color.parseColor("#FFA500"));
                        break;
                    case "purple":
                        colorFrame.setBackgroundColor(Color.parseColor("#800080"));
                        break;
                    case "pink":
                        colorFrame.setBackgroundColor(Color.parseColor("#FFC0CB"));
                        break;
                    case "black":
                        colorFrame.setBackgroundColor(Color.BLACK);
                        break;
                    case "white":
                        colorFrame.setBackgroundColor(Color.WHITE);
                        break;
                    case "gray":
                        colorFrame.setBackgroundColor(Color.GRAY);
                        break;
                }
            }
        });
    }
}
